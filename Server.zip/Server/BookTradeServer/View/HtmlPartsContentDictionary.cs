﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace RoadRunnerServer.View
{
    class HtmlPartsContentDictionary //singleton
    {
        private const string HTML_FOLDER = "View/Htmlpart/";


        public Dictionary<string, string> HtmlParts { get; private set; }

        private static HtmlPartsContentDictionary instance;

        private HtmlPartsContentDictionary() 
        {
            FindCssFile();
        }

        public static HtmlPartsContentDictionary Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new HtmlPartsContentDictionary();
                }
                return instance;
            }
        }


        private void FindCssFile()
        {
            HtmlParts = new Dictionary<string, string>();
            ProcessDirectory(HTML_FOLDER);
        }

        private void ProcessDirectory(string targetDirectory)
        {
            // Process the list of files found in the directory.
            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
                ProcessFile(fileName);

            // Recurse into subdirectories of this directory.
            string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);
            foreach (string subdirectory in subdirectoryEntries)
                ProcessDirectory(subdirectory);
        }

        private void ProcessFile(string path)
        {
            string fileName = Path.GetFileNameWithoutExtension(path);
            Program.Print("HtmlContentDictionary :< loading file " + fileName, ConsoleColor.Magenta);
            string cssFile = File.ReadAllText(path);
            HtmlParts.Add(fileName, cssFile);
        }
    }
}
