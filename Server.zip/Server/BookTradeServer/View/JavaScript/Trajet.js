﻿var map;
var directionsService;
var directionsDisplay;
function initMap() {

    directionsService = new google.maps.DirectionsService;
    directionsDisplay = new google.maps.DirectionsRenderer;
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: -34.397, lng: 150.644 },
        zoom: 8
    });
    directionsDisplay.setMap(map);


    // Try HTML5 geolocation.
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            var pos = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            map.setCenter(pos);
        });
    }

    document.getElementById('genererTrajet').addEventListener('click', function () {
        calculateAndDisplayRoute(directionsService, directionsDisplay);
    });
}

var shape = {
    coords: [1, 1, 1, 20, 18, 20, 18, 1],
    type: 'poly'
};

var waysPointmarker = [];
var waysPointValue = [];
function addPointGeo(latIn, lngIn) {
    waysPointValue.push({ lat: latIn, lng: lngIn });
    var tempMarker = new google.maps.Marker({
        position: { lat: latIn, lng: lngIn },
        map: map,
        title: 'codeMarker',
        shape: shape,
        icon: 'http://i.imgur.com/onJ70gZ.png'
    });

    var infowindow = new google.maps.InfoWindow({
        content: '<input type="text" class="form-control" placeholder="Produits livré" value=""/>'
    });
    tempMarker.addListener('click', function () {
        infowindow.open(map, tempMarker);
    });

    waysPointmarker.push(tempMarker);
}


function addPointGeoFromMenu() {
    var lati = parseFloat(document.getElementById('latitude').value);
    var longi = parseFloat(document.getElementById('longitude').value);
    addPointGeo(lati, longi);
}

var testReponse;

function calculateAndDisplayRoute(directionsService, directionsDisplay) {
    var waypts;
    waypts = [];
    for (var i = 1; i < waysPointValue.length - 1; i++) {
        waypts.push({
            location: waysPointValue[i],
            stopover: true
        });
    }

    directionsService.route({
        origin: waysPointValue[0],
        destination: waysPointValue[waysPointValue.length - 1],
        waypoints: waypts,
        optimizeWaypoints: true,
        travelMode: google.maps.TravelMode.DRIVING
    }, function (response, status) {
        if (status === google.maps.DirectionsStatus.OK) {
            directionsDisplay.setDirections(response);
            testReponse = response;
            for (var i = 0; i < waysPointmarker.length; i++) {
                waysPointmarker[i].setMap(null);
            }

        } else {
            window.alert('Directions request failed due to ' + status);
        }
    });

}

function postRoute() {
    var form = document.createElement("form");
    form.setAttribute("method", "post");
    form.setAttribute("action", "SaveRoute");

    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type", "hidden");
    hiddenField.setAttribute("name", "codeRoute");
    hiddenField.value = document.getElementById('codeRoute').value;

    form.appendChild(hiddenField);

    for (var i = 0; i < waysPointValue.length; i++) {

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.name = "Lat" + i;
        hiddenField.value = waysPointValue[i].lat;

        form.appendChild(hiddenField);

        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.name = "Lng" + i;
        hiddenField.value = waysPointValue[i].lng;

        form.appendChild(hiddenField);
    }

    document.body.appendChild(form);
    form.submit();
}