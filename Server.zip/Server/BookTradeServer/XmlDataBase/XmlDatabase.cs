﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.Outils;
using RoadRunnerServer.Database;

namespace RoadRunnerServer.XmlDataBase
{
    public class XmlDatabase : IDataBase
    {
        public const string DATABASE_PATH = "XmlDataBase";


        public XmlDatabase()
        {

        }

        public void Open()
        {

        }

        public List<T> SelectAll<T>(string table) where T : IDataModel
        {
            Program.Print("XmlDatabase :< List : " + XmlDatabase.DATABASE_PATH + "/" + table, ConsoleColor.DarkYellow);
            List<T> allTable = new List<T>();
            List<string> allName = Serializer.ListerFichiers(XmlDatabase.DATABASE_PATH + "/" + table);

            foreach (string name in allName)
            {
                Program.Print("XmlDatabase :< found : " + name, ConsoleColor.DarkYellow);
                allTable.Add(Serializer.DeSerializeObject<T>(XmlDatabase.DATABASE_PATH + "/" + table + "/" + name));
            }

            return allTable;
        }

        public T Find<T>(string table, string key) where T : IDataModel
        {
            Program.Print("XmlDatabase :< Search " + XmlDatabase.DATABASE_PATH + "/" + table + "/" + key, ConsoleColor.DarkYellow);
            return Serializer.DeSerializeObject<T>(XmlDatabase.DATABASE_PATH + "/" + table + "/" + key);
        }

        public bool Existe<T>(string table, string key) where T : IDataModel
        {
            Program.Print("XmlDatabase :< Existe? " + XmlDatabase.DATABASE_PATH + "/" + table + "/" + key, ConsoleColor.DarkYellow);
            bool exist = false;
            try
            {
                Serializer.DeSerializeObject<T>(XmlDatabase.DATABASE_PATH + "/" + table + "/" + key);
                exist = true;
            }
            catch
            {
            }
            return exist;
        }

        public void Add(IDataModel obj)
        {
            string name = obj.GetTableName();

            string dirPath = "/" + name + "/";
            string path = obj.GetKey();
            if (path != "" && path != " ")
            {
                Serializer.CreatDirIfNeeded(XmlDatabase.DATABASE_PATH);
                Serializer.CreatDirIfNeeded(XmlDatabase.DATABASE_PATH + dirPath);
                obj.Serialise(XmlDatabase.DATABASE_PATH + dirPath + path);
            }
        }

        public void AddTeste(IDataModel obj)
        {
            string name = obj.GetTableName();

            string dirPath = "/" + name + "/";
            string path = obj.GetKey();
            if (path != "" && path != " ")
            {
                Serializer.CreatDirIfNeeded(XmlDatabase.DATABASE_PATH);
                Serializer.CreatDirIfNeeded(XmlDatabase.DATABASE_PATH + "/TEST");
                Serializer.CreatDirIfNeeded(XmlDatabase.DATABASE_PATH + "/TEST/" + dirPath);
                obj.Serialise(XmlDatabase.DATABASE_PATH + "/TEST/" + dirPath + path);
            }
        }

        public void Remove(string table, string key)
        {
            Serializer.SuprimerFichier(XmlDatabase.DATABASE_PATH + "/" + table + "/" + key);
        }
    }
}
