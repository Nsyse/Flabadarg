﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RoadRunnerServer.Controller
{
    public interface IController
    {
        bool Command(string command, string info, string typeCompte);
    }
}
