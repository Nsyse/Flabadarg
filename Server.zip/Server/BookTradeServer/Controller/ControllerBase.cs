﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.IO;

namespace RoadRunnerServer.Controller
{
    public class ControllerBase : IController
    {
        protected List<Command> Commands { get; set; }
        protected List<string> TypeCompteAutorisé { get; set; } 
        private Func<string> responderMethod;
        protected string commandString;

        protected Dictionary<string,string> InfoCurrentCommand { get; set; }

        public ControllerBase()
        {
            TypeCompteAutorisé = new List<string>();
            Commands = new List<Command>();
            InfoCurrentCommand = new Dictionary<string, string>();
        }

        public bool Command(string text, string info, string typeCompte)
        {
            bool knowCommand = false;
            bool aAutorisation = false;
            foreach (string Tcompte in TypeCompteAutorisé)
            {
                if (Tcompte == typeCompte)
                {
                    aAutorisation = true;
                }
            }
            if (aAutorisation)
            {
                foreach (Command command in Commands)
                {
                    if (text == command.Name)
                    {
                        commandString = text;
                        GenerateInfoDictionary(info);
                        knowCommand = true;
                        responderMethod = command.Methode;
                        responderMethod();
                    }
                }
            }
            return knowCommand;
        }

        private void GenerateInfoDictionary(string info)
        {
            try
            {
                InfoCurrentCommand.Clear();
                string[] substring = info.Split('&');
                foreach (string element in substring)
                {
                    InfoCurrentCommand.Add(element.Split('=')[0], element.Split('=')[1]);
                }
            }
            catch
            {

            }
        }
    }
}
