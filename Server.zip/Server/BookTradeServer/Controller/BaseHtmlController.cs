﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.Controller;
using RoadRunnerServer.Web;
using RoadRunnerServer.View;
using RoadRunnerServer.UserAuthentication;
using System.IO;

namespace RoadRunnerServer.Controller
{
    public abstract class BaseHtmlController : ControllerBase//https://msdn.microsoft.com/en-us/library/07wt70x2(v=vs.110).aspx
    {
        public const string HTML_FOLDER = "View/Html/";

        private Server Listener;

        private Dictionary<string, string> htmlFiles;

        public BaseHtmlController(Server listener)
            :base()
        {
            Listener = listener;

            //FindCssFile();

            //TypeCompteAutorisé.Add(BaseUser.TYPE_ANONYMUS);
        }


        private string UploadHtml()
        {
            Program.Print("HtmlController :< UploadHtml()", ConsoleColor.Blue);
            Program.Print("HtmlController :< file " + base.commandString, ConsoleColor.Blue);
            Listener.SendResponseString = htmlFiles[base.commandString].Replace("[nonutilisateur]", Listener.GetAuthentification().GetUtilisateur().Identifiant);

           return "";
        }


        protected void FindHtmlFile(string directory)
        {
            htmlFiles = new Dictionary<string, string>();
            ProcessDirectory(directory);
        }

        private void ProcessDirectory(string targetDirectory)
        {
            // Process the list of files found in the directory.
            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
                ProcessFile(fileName);

            // Recurse into subdirectories of this directory.
            string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);
            foreach (string subdirectory in subdirectoryEntries)
                ProcessDirectory(subdirectory);
        }

        private void ProcessFile(string path)
        {
            string fileName = Path.GetFileNameWithoutExtension(path);
            Program.Print("HtmlController :< html file found " + fileName, ConsoleColor.Blue);
            Commands.Add(new Command("/" + fileName, UploadHtml));
            Program.Print("HtmlController :< loading file " + fileName, ConsoleColor.Blue);
            string cssFile = File.ReadAllText(path);
            fileName = Path.GetFileNameWithoutExtension(path);
            Program.Print("HtmlController :< adding command " + fileName, ConsoleColor.Blue);
            htmlFiles.Add("/" + fileName.ToUpper(), cssFile);
        }
    }
}
