﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RoadRunnerServer.Controller
{
    public class ControllerManager : IController// Chaine de responsabilités, Facade
    {
        private List<IController> Controllers { get; set; }

        public ControllerManager()
        {
            Controllers = new List<IController>();
        }

        public bool Command(string command, string info, string typeComtpe)
        {
            bool commandIsFound = false;
            foreach (IController controller in Controllers)
            {
                commandIsFound = controller.Command(command, info, typeComtpe);

                if (commandIsFound)
                {
                    break;
                }
            }
            return true;
        }

        public void Add(IController controller)
        {
            Controllers.Add(controller);
        }
    }
}
