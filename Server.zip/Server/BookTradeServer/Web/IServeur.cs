﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.Controller;
using RoadRunnerServer.UserAuthentication;

namespace RoadRunnerServer.Web
{
    public interface IServeur
    {
        Authentification GetAuthentification();
        void SetUtilisateur(Authentification authentification);
        void DéconnecterUtilisateur();
        string SendResponseString { get; set; }
        void SetController(IController controller);
        void Run();
        void Stop();
    }
}
