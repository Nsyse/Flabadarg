﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using RoadRunnerServer.Controller;
using RoadRunnerServer.UserAuthentication;

namespace RoadRunnerServer.Web
{
    public class Server : IServeur//Contient du code étrangé
    {
        //http://+:80/
        public const string HOST = "http://localhost:8080/";
        const string AUTH_COOKIE_NAME = "Authentification";
        const string AUTH_KEY_COOKIE_NAME = "AuthKey";

        private HttpListener HttpListener { get; set; }

        private IController Controller { get; set; }

        public string SendResponseString { get; set; }

        private Authentification Identité { get; set; }
        private bool BackEndIdentitieChange { get; set; }
        private Authentification NouvelleIdentitié { get; set; }

        public Server()
        {
            HttpListener = new HttpListener();
            if (!HttpListener.IsSupported)
            {
                throw new NotSupportedException("Needs Windows XP SP2, Server 2003 or later.");
            }
            HttpListener.Prefixes.Add(HOST);
            HttpListener.Start();
        }

        public void Run()
        {
            while (HttpListener.IsListening)
            {
                Program.Print("");
                Program.Print("Server :< Listening...", ConsoleColor.Green);
                // Note: The GetContext method blocks while waiting for a request. 
                HttpListenerContext context = HttpListener.GetContext();
                HttpListenerRequest request = context.Request;

                if (context.Request.Cookies.Count > 0)
                {
                    foreach (Cookie cookie in context.Request.Cookies)
                    {
                        if (cookie.Name == AUTH_COOKIE_NAME)
                        {
                            Program.Print("Server :< COOKIES user : " + cookie.Value, ConsoleColor.White);
                            Identité = new Authentification(cookie.Value);
                        }
                        if (cookie.Name == AUTH_KEY_COOKIE_NAME)
                        {
                            Program.Print("Server :< COOKIES key : " + cookie.Value, ConsoleColor.White);
                            Identité.Clef = cookie.Value;
                        }
                    }
                }
                // Obtain a response object.
                HttpListenerResponse response = context.Response;
                response.AppendHeader("Access-Control-Allow-Origin", "*");

                // Construct a response.
                Program.Print("Server :< Receive : " + request.RawUrl.ToString(), ConsoleColor.Green);

                string responseString = SendResponse(request);

                if (responseString != "")
                {
                    Program.Print("Server :< Send : webpage", ConsoleColor.Green);
                    //Console.WriteLine("Server :< Send : " + responseString, ConsoleColor.DarkMagenta);
                    byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString);

                    if (BackEndIdentitieChange)
                    {
                        response.SetCookie(new Cookie(AUTH_COOKIE_NAME, NouvelleIdentitié.IdentifiantUtilisateur));
                        response.SetCookie(new Cookie(AUTH_KEY_COOKIE_NAME, NouvelleIdentitié.Clef));
                        BackEndIdentitieChange = false;
                    }
                    else
                    {
                        Identité.ResetKey();
                        Identité.UpdateInDatabase();
                        response.SetCookie(new Cookie(AUTH_COOKIE_NAME, Identité.IdentifiantUtilisateur));
                        response.SetCookie(new Cookie(AUTH_KEY_COOKIE_NAME, Identité.Clef));
                    }

                    // Get a response stream and write the response to it.
                    response.ContentLength64 = buffer.Length;
                    System.IO.Stream output = response.OutputStream;
                    output.Write(buffer, 0, buffer.Length);
                    output.Close();
                    Program.Print("Server :< close output ", ConsoleColor.Green);
                }
            }
        }


 
        public void Stop()
        {
            HttpListener.Stop();
            HttpListener.Close();
        }

        public Authentification GetAuthentification()
        {
            if (Identité == null)
            {
                Identité = Authentification.GetAnonymus();
            }
            return Identité;
        }

        public void DéconnecterUtilisateur()
        {
            Identité = null;
            SetUtilisateur(Authentification.GetAnonymus());
        }


        public void SetUtilisateur(Authentification authentification)// n'est pas asyncrone... 
        {
            BackEndIdentitieChange = true;
            NouvelleIdentitié = authentification;
        }

        private string SendResponse(HttpListenerRequest request)
        {
            SendResponseString = "";

            string postedtext = GetPostedText(request);
            Program.Print("Server :< Request content : " + postedtext, ConsoleColor.Green);
            Program.Print("Server :< user type : " + GetAuthentification().GetUtilisateur().Type, ConsoleColor.Green);
            Program.Print("Server :< user id : " + GetAuthentification().GetUtilisateur().Identifiant, ConsoleColor.Green);
            Controller.Command(request.RawUrl.ToString().ToUpper(), postedtext, GetAuthentification().GetUtilisateur().Type);

            return SendResponseString;
        }

        public void SetController(IController controller)
        {
            Controller = controller;
        }

        private static string GetPostedText(HttpListenerRequest request)
        {
            string recievedText;

            using (StreamReader reader = new StreamReader(request.InputStream, request.ContentEncoding))
            {
                recievedText = reader.ReadToEnd();
            }

            return Decode(recievedText);
        }

        private static string Decode(string EncodedData)
        {
            return EncodedData.Replace("%C3%A9", "é")
                .Replace("%C3%87", "Ç")
                .Replace("%C3%A0", "à")
                .Replace("%C3%A7", "ç")
                .Replace("%C3%80", "À")
                .Replace("%C3%89", "É")
                .Replace("%27", "'")
                .Replace("%C3%A8", "è")
                .Replace("%C3%88", "È")
                .Replace("%C3%AA", "ê")
                .Replace("%C3%8A", "Ê")
                .Replace("%C3%AB", "ë")
                .Replace("%C3%8B", "Ë")
                .Replace("%3A", ":")
                .Replace("%3B", ";")
                .Replace("%28", "(")
                .Replace("%29", ")")
                .Replace("+", " ")
                .Replace("%40", "@")
                .Replace("%2C", ","); //Trouver un meilleur formatage..
        }
    }
}
