﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RoadRunnerServer.Outils
{
    public class Hasher//Singleton 
    {
        //singleton et non static car à besion d'une instance de Random.
        private static Hasher instance;

        private Hasher()
        {

        }

        public static Hasher Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Hasher();
                }
                return instance;
            }
        }

        public string Hash(string uncodeString)
        {
            return uncodeString;
        }
    }
}