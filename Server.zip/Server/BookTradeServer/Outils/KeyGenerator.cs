﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RoadRunnerServer.Outils
{
    public class KeyGenerator//Singleton 
    {
        //singleton et non static car à besion d'une instance de Random.
        private static KeyGenerator instance;

        private KeyGenerator()
        {

        }

        public static KeyGenerator Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new KeyGenerator();
                }
                return instance;
            }
        }

        public string GetNewKey(int nbChar)
        {
            string key = "";
            for (int i = 0; i < nbChar; i++)
            {
                key += ((char)Aléatoire.Instance.Next(64,100));
            }
            return key;
        }
    }
}