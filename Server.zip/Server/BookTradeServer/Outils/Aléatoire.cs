﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RoadRunnerServer.Outils
{
    public class Aléatoire//Singleton 
    {
        //singleton et non static car à besion d'une instance de Random.
        private Random random;
        private static Aléatoire instance;

        private Aléatoire()
        {
            random = new Random();
        }

        public static Aléatoire Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Aléatoire();
                }
                return instance;
            }
        }

        public int Next(int min, int max)
        {
            return random.Next(min, max);
        }
    }
}