﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.UserAuthentication;
using RoadRunnerServer.Outils;
using RoadRunnerServer.Database;

namespace RoadRunnerServer.Model
{
    public class Route : IDataModel
    {
        public const string TABLE_NAME = "Route";

        public string Code { get; set; }
        public List<Waypoint> Waypoints { get; set; }


        public Route() { }

        public Route(string code, List<Waypoint> waypoints)
        {
            Code = code;
            Waypoints = waypoints;
        }


        public string GetInsert() { return ""; }

        public string GetTableName()
        {
            return TABLE_NAME;
        }


        public string GetKey()
        {
            return Code;
        }

        public void Serialise(string path)
        {
            Serializer.SerializeObject<Route>(this, path);
        }

    }
}
