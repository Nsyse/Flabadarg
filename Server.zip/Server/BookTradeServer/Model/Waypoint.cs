﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RoadRunnerServer.Model
{
    public class Waypoint
    {
        public float Latitude { get; set; }
        public float Longitude { get; set; }

        public Waypoint() { }

        public Waypoint(float lat, float lng)
        {
            Latitude = lat;
            Longitude = lng;
        }
    }
}
