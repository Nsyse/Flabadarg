﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.UserAuthentication;

namespace RoadRunnerServer.Model
{
    public class TruckDriver : BaseUser
    {
        public TruckDriver() { }

        public TruckDriver(string identifiant, string password)
            :base(identifiant, password, UserType.TruckDriver)
        {
        }

    }
}
