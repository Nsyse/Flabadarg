﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.UserAuthentication;

namespace RoadRunnerServer.Model
{
    public class Administrator : BaseUser
    {
        public Administrator() { }

        public Administrator(string identifiant, string password)
            : base(identifiant, password, UserType.Administrateur)
        {
            
        }

    }
}
