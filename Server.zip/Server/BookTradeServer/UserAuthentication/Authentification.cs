﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.Outils;
using RoadRunnerServer.Database;

namespace RoadRunnerServer.UserAuthentication
{
    public class Authentification : IDataModel //methode template (polymorphisme)
    {
        //Cette classe represente le model et le model de donnée pour maintennir
        //l'authentification d'un utilisateur dans un contexte http.

        public const string TABLE_NAME = "Authentification";
        public const string ANONYMUS = "Anonymus";

        public string IdentifiantUtilisateur { get; set; }//Utilisateur
        public string Clef { get; set; }
        private BaseUser Utilisateur;

        public Authentification() { }

        public static Authentification GetAnonymus()
        {
            return new Authentification(ANONYMUS);
        }
            
        public Authentification(string utilisateur)
        {
            IdentifiantUtilisateur = utilisateur;
            ResetKey();
        }

        public Authentification(string utilisateur, string clef)
        {
            IdentifiantUtilisateur = utilisateur;
            Clef = clef;
        }

        public void ResetKey()
        {
            Clef = KeyGenerator.Instance.GetNewKey(50);
            Utilisateur = null;
        }

        public void UpdateInDatabase()
        {
            DataBase.Instance.Add(this);
        }

        public BaseUser GetUtilisateur()
        {
            BaseUser utilisateur;
            if (Utilisateur == null)
            {
                if (DataBase.Instance.Existe<BaseUser>(BaseUser.TABLE_NAME, IdentifiantUtilisateur))
                {
                    utilisateur = DataBase.Instance.Find<BaseUser>(BaseUser.TABLE_NAME, IdentifiantUtilisateur);
                    if (DataBase.Instance.Existe<Authentification>(Authentification.TABLE_NAME, utilisateur.Identifiant))
                    {
                        Authentification authentification = DataBase.Instance.Find<Authentification>(Authentification.TABLE_NAME, utilisateur.Identifiant);
                        if (authentification.Clef == Clef)
                        {
                            Program.Print("Authentification :< Authentification réussi.", ConsoleColor.White);
                        }
                        else
                        {
                            utilisateur = Anonymus();
                        }
                    }
                    else
                    {
                        utilisateur = Anonymus();
                    }
                }
                else
                {
                    utilisateur = Anonymus();
                    
                }
                Utilisateur = utilisateur;
            }
            else
            {
                utilisateur = Utilisateur;
                Program.Print("Authentification :< Authentification mémoire.", ConsoleColor.White);
            }
            return utilisateur;
        }

        private BaseUser Anonymus()
        {
            return new BaseUser(ANONYMUS);
        }

        public string GetInsert() { return ""; }

        public string GetTableName()
        {
            return TABLE_NAME;
        }

        public string GetKey()
        {
            return IdentifiantUtilisateur;
        }

        public void Serialise(string path)
        {
            Serializer.SerializeObject<Authentification>(this, path);
        }
    }
}
