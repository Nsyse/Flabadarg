﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.Outils;
using RoadRunnerServer.Database;
using System.Xml.Serialization;
using RoadRunnerServer.Model;

namespace RoadRunnerServer.UserAuthentication
{
    [Serializable]
    [XmlInclude(typeof(TruckDriver))]
    [XmlInclude(typeof(Administrator))]
    public class BaseUser : IDataModel
    {
        //Classe de base pour la création de compte

        public const string TABLE_NAME = "Utilisateur";
        public const string TYPE_ANONYMUS = "Anonymus";

        public string Identifiant { get; set; }
        public string Password { get; set; }
        public string Type { get; set; }

        public BaseUser() { }

        public BaseUser(string identifiant)
        {
            Identifiant = identifiant;
            Type = TYPE_ANONYMUS;
            Password = "";
        }

        public BaseUser(string identifiant, string password, string type)
        {
            Identifiant = identifiant;
            Password = password;
            Type = type;
        }

        public string GetInsert() { return ""; }

        public string GetTableName()
        {
            return TABLE_NAME;
        }


        public string GetKey()
        {
            return Identifiant;
        }

        public void Serialise(string path)
        {
            Serializer.SerializeObject<BaseUser>(this, path);
        }
    }
}
