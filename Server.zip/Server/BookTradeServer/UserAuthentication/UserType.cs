﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RoadRunnerServer.UserAuthentication
{
    public class UserType
    {
        public const string TruckDriver = "TruckDriver";
        public const string Administrateur = "Administrateur";
    }
}
