﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RoadRunnerServer.Database
{
    interface IDataBase
    {
        void Open();

        List<T> SelectAll<T>(string table) where T : IDataModel;

        T Find<T>(string table, string key) where T : IDataModel;

        bool Existe<T>(string table, string key) where T : IDataModel;

        void Add(IDataModel obj);

        void AddTeste(IDataModel obj);

        void Remove(string table, string key);
    }
}
