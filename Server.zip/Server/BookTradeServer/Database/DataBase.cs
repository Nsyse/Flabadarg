﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.XmlDataBase;

namespace RoadRunnerServer.Database
{
    public class DataBase//Adapatator, Proxy & Singleton
    {
        private static DataBase instance;
        private IDataBase database;

        private DataBase() { }

        public static DataBase Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new DataBase();
                }
                return instance;
            }
        }

        public void Open()
        {
            database = new XmlDatabase();//DataBase temporaire xml
            database.Open();
        }

        public List<T> SelectAll<T>(string table) where T : IDataModel
        {
            Program.Print("DataBase :< SelectAll " + table, ConsoleColor.Yellow);
            return database.SelectAll<T>(table);
        }


        public T Find<T>(string table, string key) where T : IDataModel
        {
            Program.Print("DataBase :< Find " + table + " " + key, ConsoleColor.Yellow);
            return database.Find<T>(table, key);
        }

        public bool Existe<T>(string table, string key) where T : IDataModel
        {
            Program.Print("Existe :< Find " + table + " " + key, ConsoleColor.Yellow);
            return database.Existe<T>(table, key);
        }

        public void Add(IDataModel obj)
        {
            Program.Print("DataBase :< Add " + obj.GetType(), ConsoleColor.Yellow);
            database.Add(obj);
        }

        public void AddTeste(IDataModel obj)
        {
            Program.Print("DataBase :< AddTeste " + obj.GetType(), ConsoleColor.Yellow);
            database.AddTeste(obj);
        }

        public void Remove(string table, string key)
        {
            Program.Print("DataBase :< Remove " + table + " " + key, ConsoleColor.Yellow);
            database.Remove(table, key);
        }
    }
}
