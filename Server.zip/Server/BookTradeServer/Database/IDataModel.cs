﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RoadRunnerServer.Database
{
    public interface IDataModel
    {
        string GetKey();//key de la table
        string GetTableName();//nom de la table
        string GetInsert();//formule pour inserrer la table
        void Serialise(string path);//temporaire
    }
}
