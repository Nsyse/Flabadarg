﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.Controller;
using RoadRunnerServer.Web;
using RoadRunnerServer.View;
using RoadRunnerServer.UserAuthentication;
using RoadRunnerServer.Database;
using RoadRunnerServer.Model;

namespace RoadRunnerServer.ConcreteController
{
    class UserController : ControllerBase
    {
        private Server Listener;

        public UserController(Server listener)
            :base()
        {
            Listener = listener;
            Commands.Add(new Command("/ConnectionAction", ConnectAction));
            Commands.Add(new Command("/DeconnectionAction", DeconnectAction));
            Commands.Add(new Command("/Creation", CreeTest));

            TypeCompteAutorisé.Add(BaseUser.TYPE_ANONYMUS);
            TypeCompteAutorisé.Add(UserType.TruckDriver);
            TypeCompteAutorisé.Add(UserType.Administrateur);
        }

        private string ConnectAction()
        {
            Program.Print("UserController :< ConnectAction()" , ConsoleColor.Blue);
            try
            {
                Program.Print("UserController :< Connecting user " + InfoCurrentCommand["email"], ConsoleColor.Blue);
                Listener.DéconnecterUtilisateur();

                if (DataBase.Instance.Existe<BaseUser>(BaseUser.TABLE_NAME, InfoCurrentCommand["email"]))
                {
                    BaseUser user = DataBase.Instance.Find<BaseUser>(BaseUser.TABLE_NAME, InfoCurrentCommand["email"]);

                    if (user.Password == InfoCurrentCommand["password"])
                    {
                        Authentification newAuthentification = new Authentification(user.Identifiant);
                        DataBase.Instance.Add(newAuthentification);
                        Listener.SetUtilisateur(newAuthentification);
                        Listener.SendResponseString = HtmlPartsContentDictionary.Instance.HtmlParts["RoadRunner_MapRedirecting"];
                    }
                    else
                    {
                        Program.Print("UserController :< Wrong password", ConsoleColor.Blue);
                        Listener.SendResponseString = HtmlPartsContentDictionary.Instance.HtmlParts["IndexRedirecting"];
                    }
                }
                else
                {
                    Program.Print("UserController :< User dont exist", ConsoleColor.Blue);
                    Listener.SendResponseString = HtmlPartsContentDictionary.Instance.HtmlParts["IndexRedirecting"];
                }

            }
            catch
            {
            }
            



            return "";
        }

        private string DeconnectAction()
        {
            Program.Print("UserController :< DeconnectAction()", ConsoleColor.Blue);

            Listener.DéconnecterUtilisateur();
            Listener.SendResponseString = HtmlPartsContentDictionary.Instance.HtmlParts["IndexRedirecting"];

            return "";
        }

        private string CreeTest()
        {
            Program.Print("UserController :< CreeTest()", ConsoleColor.Blue);

            DataBase.Instance.Add(new BaseUser("Xavier", "Xavier", UserType.TruckDriver));
            DataBase.Instance.Add(new BaseUser("Marc", "Marc", UserType.TruckDriver));
            DataBase.Instance.Add(new BaseUser("Gabriel", "Gabriel", UserType.TruckDriver));
            DataBase.Instance.Add(new BaseUser("Laurier", "Laurier", UserType.TruckDriver));

            return "";
        }
    }
}
