﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.Controller;
using RoadRunnerServer.Web;
using RoadRunnerServer.View;
using RoadRunnerServer.UserAuthentication;
using System.IO;

namespace RoadRunnerServer.ConcreteController
{
    class IndexController : ControllerBase
    {
        private const string PATH_INDEX = "View/html/RoadRunner.html";

        private Server Listener;

        string indexPage;

        public IndexController(Server listener)
            :base()
        {
            Listener = listener;
            Commands.Add(new Command("/", Index));
            Commands.Add(new Command("/index", Index));

            SetIndex(PATH_INDEX);

            TypeCompteAutorisé.Add(BaseUser.TYPE_ANONYMUS);
            TypeCompteAutorisé.Add(UserType.TruckDriver);
            TypeCompteAutorisé.Add(UserType.Administrateur);
        }

        private string Index()
        {
            Program.Print("IndexController :< Index()", ConsoleColor.Blue);


            if (Listener.GetAuthentification().GetUtilisateur().Type == BaseUser.TYPE_ANONYMUS)
            {
                Listener.SendResponseString = indexPage;
            }
            else
            {
                Listener.SendResponseString = HtmlPartsContentDictionary.Instance.HtmlParts["RoadRunner_MapRedirecting"];
            }

            return "";
        }

        private void SetIndex(string path)
        {
            indexPage = File.ReadAllText(path);
        }

    }
}
