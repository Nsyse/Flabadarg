﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.Controller;
using RoadRunnerServer.Web;
using RoadRunnerServer.UserAuthentication;

namespace RoadRunnerServer.ConcreteController
{
    class TruckDriverHtmlController : BaseHtmlController
    {
        private const string USER_FOLDER = "TruckDriver/";

        public TruckDriverHtmlController(Server listener)
            : base(listener)
        {
            FindHtmlFile(BaseHtmlController.HTML_FOLDER + USER_FOLDER);

            TypeCompteAutorisé.Add(UserType.TruckDriver);
            TypeCompteAutorisé.Add(UserType.Administrateur);
        }
    }
}
