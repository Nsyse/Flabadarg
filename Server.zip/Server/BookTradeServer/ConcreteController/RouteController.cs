﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.Controller;
using RoadRunnerServer.Web;
using RoadRunnerServer.View;
using RoadRunnerServer.UserAuthentication;
using System.IO;
using RoadRunnerServer.Database;
using RoadRunnerServer.Model;
using System.Globalization;

namespace RoadRunnerServer.ConcreteController
{
    class RouteController : ControllerBase
    {
        private const string PATH_INDEX = "View/html/RoadRunner.html";

        private Server Listener;

        public RouteController(Server listener)
            :base()
        {
            Listener = listener;
            Commands.Add(new Command("/ChargerRoute", ChargerRoute));
            Commands.Add(new Command("/SaveRoute", SaveRoute));

            TypeCompteAutorisé.Add(UserType.TruckDriver);
            TypeCompteAutorisé.Add(UserType.Administrateur);
        }

        private string ChargerRoute()// 
        {
            Program.Print("RouteController :< ChargerRoute()", ConsoleColor.Blue);
            try
            {
                string codeRoute = InfoCurrentCommand["codeRoute"];
                if (DataBase.Instance.Existe<Route>(Route.TABLE_NAME, codeRoute))
                {
                    Route route = DataBase.Instance.Find<Route>(Route.TABLE_NAME, codeRoute);
                    string wayPoints = "";
                    foreach (Waypoint wpoint in route.Waypoints)
                    {
                        Program.Print("RouteController :< wayPoints add", ConsoleColor.Blue);
                        wayPoints += MakeWayPointString(wpoint);
                    }

                    Listener.SendResponseString = HtmlPartsContentDictionary.Instance.HtmlParts["RoadRunner_Map"];
                    Listener.SendResponseString = Listener.SendResponseString.Replace("//[WayPoints]", wayPoints);
                    Listener.SendResponseString = Listener.SendResponseString.Replace("[Route]", "Route " + route.Code);
                    Listener.SendResponseString = Listener.SendResponseString.Replace("[nonutilisateur]", Listener.GetAuthentification().GetUtilisateur().Identifiant);
                    //[WayPoints]
                }
            }
            catch {}

            return "";
        }

        private string MakeWayPointString(Waypoint wp)
        {
            return "addPointGeo(" + wp.Latitude.ToString().Replace(",", ".") + "," + wp.Longitude.ToString().Replace(",", ".") + "); ";
        }

        private string SaveRoute()
        {
            Program.Print("RouteController :< SaveRoute()", ConsoleColor.Blue);
            try
            {
                string codeRoute = InfoCurrentCommand["codeRoute"];
                Program.Print("RouteController :< Code : " + codeRoute, ConsoleColor.Blue);
                List<Waypoint> waysPoints = new List<Waypoint>();
                try
                {
                    int i = 0;
                    while (InfoCurrentCommand["Lat" + i.ToString()] != null && i < 23)
                    {
                        Program.Print("RouteController :< Lat" + i.ToString() + " : " + InfoCurrentCommand["Lat" + i.ToString()], ConsoleColor.Blue);
                        Program.Print("RouteController :< Lng" + i.ToString() + " : " + InfoCurrentCommand["Lng" + i.ToString()], ConsoleColor.Blue);
                        waysPoints.Add(new Waypoint(float.Parse(InfoCurrentCommand["Lat" + i.ToString()], CultureInfo.InvariantCulture.NumberFormat), float.Parse(InfoCurrentCommand["Lng" + i.ToString()], CultureInfo.InvariantCulture.NumberFormat)));
                        i++;
                    }
                }
                catch { }

                if (codeRoute != "")
                {
                    DataBase.Instance.Add(new Route(codeRoute, waysPoints));
                }
            }
            catch { }

            

            return "";
        }


    }
}
