﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.Controller;
using RoadRunnerServer.Web;
using RoadRunnerServer.View;
using RoadRunnerServer.UserAuthentication;
using System.IO;

namespace RoadRunnerServer.ConcreteController
{
    class JavaScriptController : ControllerBase//https://msdn.microsoft.com/en-us/library/07wt70x2(v=vs.110).aspx
    {
        private const string CSS_FOLDER = "View/JavaScript/";

        private Server Listener;

        private Dictionary<string, string> jsFiles;

        public JavaScriptController(Server listener)
            :base()
        {
            Listener = listener;

            FindCssFile();

            TypeCompteAutorisé.Add(BaseUser.TYPE_ANONYMUS);
            TypeCompteAutorisé.Add(UserType.TruckDriver);
            TypeCompteAutorisé.Add(UserType.Administrateur);
        }


        private string UploadJavaScript()
        {
            Program.Print("JavaScriptController :< UploadJavaScript()", ConsoleColor.Blue);
            Program.Print("JavaScriptController :< file " + base.commandString, ConsoleColor.Blue);
            Listener.SendResponseString = jsFiles[base.commandString]; ;//PageIndex.Page(Listener.GetAuthentification());

           return "";
        }


        private void FindCssFile()
        {
            jsFiles = new Dictionary<string, string>();
            ProcessDirectory(CSS_FOLDER);
        }

        private void ProcessDirectory(string targetDirectory)
        {
            // Process the list of files found in the directory.
            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
                ProcessFile(fileName);

            // Recurse into subdirectories of this directory.
            string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);
            foreach (string subdirectory in subdirectoryEntries)
                ProcessDirectory(subdirectory);
        }

        private void ProcessFile(string path)
        {
            string fileName = Path.GetFileName(path);
            Program.Print("JavaScriptController :< css file found " + fileName, ConsoleColor.Blue);
            Commands.Add(new Command("/" + fileName, UploadJavaScript));
            Program.Print("JavaScriptController :< loading file " + fileName, ConsoleColor.Blue);
            string cssFile = File.ReadAllText(path);
            jsFiles.Add("/" + fileName.ToUpper(), cssFile);
        }
    }
}
