﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RoadRunnerServer.Controller;
using RoadRunnerServer.ConcreteController;
using RoadRunnerServer.Web;
using RoadRunnerServer.Database;
using System.IO;

namespace RoadRunnerServer
{
    public class Program
    {
        
        static void Main(string[] args)
        {
            Console.Title = "RoadRunnerServer";

            Print("Program :< Create Server");
            Server webServer = new Server();

            Print("Program :< Create contoller manager");
            ControllerManager controller = new ControllerManager();

            Print("Program :< Add Index Controller");
            controller.Add(new IndexController(webServer));
            Print("Program :< Add Test Controller");
            controller.Add(new UserController(webServer));
            Print("Program :< Add Css Controller");
            controller.Add(new CssController(webServer));
            Print("Program :< Add Js Controller");
            controller.Add(new JavaScriptController(webServer));
            Print("Program :< Add Truck Driver Html Controller");
            controller.Add(new TruckDriverHtmlController(webServer));
            Print("Program :< Add Route Controller");
            controller.Add(new RouteController(webServer));
            

            Print("Program :< Coupeling controllers to server");
            webServer.SetController(controller);

            Print("Program :< Connect to database...");
            DataBase.Instance.Open();

            webServer.Run();
            webServer.Stop();
        }
        
        public static void Print(string text)
        {
            Console.WriteLine(text);
        }

        public static void Print(string text, ConsoleColor color)
        {
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;
            Console.WriteLine(text);
            Console.ForegroundColor = oldColor;
        }
    }
}
